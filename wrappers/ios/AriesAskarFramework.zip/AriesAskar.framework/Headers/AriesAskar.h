//
//  AriesAskar.h
//  AriesAskar
//
//  Created by Alonso Yoshio Alvarez Tengan on 8/4/21.
//

#import <Foundation/Foundation.h>

//! Project version number for AriesAskar.
FOUNDATION_EXPORT double AriesAskarVersionNumber;

//! Project version string for AriesAskar.
FOUNDATION_EXPORT const unsigned char AriesAskarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AriesAskar/PublicHeader.h>
#import <AriesAskar/AskarWallet.h>
